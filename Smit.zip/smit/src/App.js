import logo from './logo.svg';
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

function App() {
    return (

        <
        div className = 'App' >

        <
        div className = "container-fluid" >
        <
        div className = "container text-white bg-dark px-0" >
        <
        div className = "row pt-3" >
        <
        div className = "col-md-1" > < /div> <
        div className = "col-md-8" >
        <
        h1 > Title of longer < br / > featured blog post < /h1> <
        /div> <
        div className = "col-md-3" > < /div> <
        /div> <
        div className = "row pb-3" >
        <
        div className = "col-md-1" > < /div> <
        div className = "col-md-8" >
        <
        p > Lorem ipsum dolor sit amet consectetur adipisicing elit.Beatae, ullam. < br / > Lorem ipsum dolor sit amet consectetur adipisicing elit.Quos, cumque. < br / > Lorem ipsum dolor sit, amet consectetur adipisicing elit.Eveniet, asperiores. <
        /p><br/ >
        <
        b > Continue Reading... < /b> <
        /div> <
        div className = "col-md-3" > < /div> <
        /div>

        <
        /div> <
        div className = "container" >
        <
        div className = "row" >
        <
        div className = "col-md-6 p-0" >
        <
        div className = "card" >
        <
        div className = "card-body" >
        <
        h5 className = "card-title" > Special title treatment < /h5> <
        p className = "card-text" > With supporting text below as a natural lead - in to additional content. < /p> <
        p className = "card-text" > With supporting text below as a natural lead - in to additional content. < /p> <
        p className = "card-text" > With supporting text below as a natural lead - in to additional content. < /p> <
        p className = "card-text" > With supporting text below as a natural lead - in to additional content. < /p>

        <
        /div> <
        /div> <
        /div> <
        div className = "col-md-6 pr-0" >
        <
        div className = "card" >
        <
        div className = "card-body" >
        <
        h5 className = "card-title" > Special title treatment < /h5> <
        p className = "card-text" > With supporting text below as a natural lead - in to additional content. < /p> <
        p className = "card-text" > With supporting text below as a natural lead - in to additional content. < /p> <
        p className = "card-text" > With supporting text below as a natural lead - in to additional content. < /p> <
        p className = "card-text" > With supporting text below as a natural lead - in to additional content. < /p> <
        /div> <
        /div> <
        /div> <
        /div> <
        /div> <
        div className = "container mt-3" >
        <
        div className = "row" >
        <
        div className = "col-md-8 p-0" >
        <
        h1 > From the firehouse < /h1> <
        hr / >
        <
        h1 > Sample blog post < /h1> <
        p > Lorem ipsum dolor sit, amet consectetur adipisicing elit.Quae sequi accusantium rerum officia excepturi maiores, omnis magnam et rem aliquid quis, nulla a saepe repellendus ipsa mollitia tempora similique ex. < /p> <
        hr / >
        <
        p > Lorem ipsum dolor sit amet consectetur adipisicing elit.Asperiores laborum cum, officiis sint deserunt pariatur eius aliquam, itaque, quam nihil deleniti eligendi ratione omnis ipsum sit corporis provident.Dolores, eius! < /p> <
        p > Lorem ipsum dolor sit amet consectetur adipisicing elit.Asperiores laborum cum, officiis sint deserunt pariatur eius aliquam, itaque, quam nihil deleniti eligendi ratione omnis ipsum sit corporis provident.Dolores, eius! < /p> <
        p > Lorem ipsum dolor sit amet consectetur adipisicing elit.Asperiores laborum cum, officiis sint deserunt pariatur eius aliquam, itaque, quam nihil deleniti eligendi ratione omnis ipsum sit corporis provident.Dolores, eius! < /p> <
        h3 > Heading < /h3> <
        p > Lorem ipsum dolor sit amet consectetur, adipisicing elit.Nesciunt dolor laborum autem eius dolorem architecto iste cupiditate ? Eum totam ratione vero illo repudiandae facere sunt modi, quo voluptatibus eos provident. < /p> <
        h3 > Sub - Heading < /h3> <
        p > Lorem ipsum dolor sit amet, consectetur adipisicing elit.Et recusandae error totam, vel sapiente quasi sit iste dolorum, illo doloremque aliquid.Odit culpa similique vero reiciendis amet ducimus ullam beatae. < /p> <
        p > Lorem ipsum dolor sit amet, consectetur adipisicing elit.Et recusandae error totam, vel sapiente quasi sit iste dolorum, illo doloremque aliquid.Odit culpa similique vero reiciendis amet ducimus ullam beatae. < /p> <
        ul >
        <
        li > Lorem ipsum dolor sit amet consectetur adipisicing elit.Laudantium, officiis ? < /li> <
        li > Lorem ipsum dolor sit amet consectetur adipisicing elit.Laudantium, officiis ? < /li> <
        li > Lorem ipsum dolor sit amet consectetur adipisicing elit.Laudantium, officiis ? < /li> <
        /ul> <
        p > Lorem, ipsum dolor sit amet consectetur adipisicing elit.Laboriosam corrupti aut voluptatem. < /p> <
        ol >
        <
        li > Lorem ipsum dolor sit amet consectetur adipisicing elit.Sequi, non. < /li> <
        li > Lorem ipsum dolor sit amet consectetur adipisicing elit.Sequi, non. < /li> <
        li > Lorem ipsum dolor sit amet consectetur adipisicing elit.Sequi, non. < /li> <
        /ol> <
        p > Lorem ipsum dolor sit amet consectetur adipisicing elit.Fugiat autem voluptas magnam! < /p> <
        /div> <
        div className = "col-md-4 pr-0" >
        <
        div className = "card bg-light" >
        <
        div className = "card-body" >
        <
        h5 className = "card-title" > About US < /h5> <
        p className = "card-text" > With supporting text below as a natural lead - in to additional content. < /p> <
        p className = "card-text" > With supporting text below as a natural lead - in to additional content. < /p> <
        /div> <
        /div> <
        h4 className = "mt-2" > Archive < /h4> <
        ul style = "list-style: none;" >
        <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        /ul> <
        h4 > ElseWhere < /h4> <
        ul style = "list-style: none;" >
        <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        li >
        <
        a href = "#" > March 2014 < /a> <
        /li> <
        /ul> <
        /div> <
        /div>

        <
        /div><br/ >
        <
        div className = "container" >
        <
        div className = "row" >
        <
        div className = "col-md-8 p-0" >
        <
        h1 > Another blog post < /h1> <
        p > Lorem ipsum dolor, sit amet consectetur adipisicing elit.Iusto maxime labore at nisi dignissimos perferendis expedita, quas nihil reiciendis optio quos ipsum quasi praesentium, pariatur porro error commodi officiis asperiores. < /p> <
        /div> <
        /div> <
        /div>

        <
        /div> </div >

    );
}

export default App;